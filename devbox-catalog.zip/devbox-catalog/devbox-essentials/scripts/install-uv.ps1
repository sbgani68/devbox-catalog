Write-Host "Installing UV (latest version)..."

irm https://astral.sh/uv/install.ps1 | powershell -
