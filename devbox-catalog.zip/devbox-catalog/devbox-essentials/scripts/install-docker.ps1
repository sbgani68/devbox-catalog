Write-Host "Installing Docker Desktop via WinGet (latest version)..."

winget install --id Docker.DockerDesktop -e --accept-source-agreements --accept-package-agreements
