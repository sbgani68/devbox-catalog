# Dev Box Catalog – DevBox Essentials (Modular)

This catalog contains a modular Dev Box customization that installs WSL2, Docker Desktop, Git, VS Code, Python, UV, and Slack.
